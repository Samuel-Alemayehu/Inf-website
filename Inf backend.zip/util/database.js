// const modgodb = require("mongodb");
// const MongoClient = modgodb.MongoClient;
// let _db;
// const mongoConnect = () => {
//   MongoClient.connect(
//     // "mongodb+srv://sami:HgEnXx2P4DLaY13k@cluster0.smt3oin.mongodb.net/?retryWrites=true&w=majority"
//     "mongodb+srv://samuel:ZF6IdqUFmf3IUCad@cluster0.smt3oin.mongodb.net/?retryWrites=true&w=majority"
//   )
//     .then((res) => {
//       console.log("connected");
//       _db = res.db("shop");
//     })
//     .catch((err) => console.log(err));
// };
// const getDb = () => {
//   if (_db) {
//     return _db;
//   }
//   throw "No data base found";
// };

// exports.mongoConnect = mongoConnect;
// exports.getDb = getDb;
