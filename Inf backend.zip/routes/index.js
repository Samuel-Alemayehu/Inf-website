const router = require("express").Router();
const multer = require("multer");
const path = require("path");
const db = require("../connection/connect");

const multerConfig = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, path.join(__dirname, "../../New inf/yeab/public"));
  },
  filename: (req, file, callback) => {
    const ext = file.mimetype.split("/")[1];
    callback(null, `image-${Date.now()}.${ext}`);
  },
});
const isImage = (req, file, cb) => {
  if (file.mimetype.startsWith("image")) {
    cb(null, true);
  } else {
    cb(new Error("Please upload image only"));
  }
};
const upload = multer({ storage: multerConfig, fileFilter: isImage });
router.get("/uploadImage", (req, res, next) => {
  db.execute("select * from images")
    .then((resp) => {
      console.log(resp[0]);
      res.json({ response: resp[0] });
    })
    .catch((err) => {
      console.log(err);
    });
});
router.post("/uploadImage", upload.single("photo"), (req, res) => {
  console.log(req.file.filename);
  try {
    db.execute("INSERT into images(Url,imagetype) values(?,?)", [
      // `/${req.file.filename}.${req.file.mimetype.split("/")[1]}`,
      `/${req.file.filename}`,
      "price",
    ])
      .then(() => {
        res.status(200).json({ success: "sucess" });
      })
      .catch((err) => {
        console.log(err);
      });
  } catch (error) {}
});
module.exports = router;
