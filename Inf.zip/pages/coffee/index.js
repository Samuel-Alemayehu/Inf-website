import Coffee from "../../components/coffee.js/infinityCoffee";
export default function InfinityCoffee() {
  return (
    <>
      <Coffee />
    </>
  );
}
