import Infinityken from "../../components/Infinityk/Infin";
export default function InfinityCoffee() {
  return (
    <>
      <Infinityken/>
    </>
  );
}