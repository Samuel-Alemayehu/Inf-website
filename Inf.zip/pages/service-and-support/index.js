import Techinical from "../../components/Technical SERVICE/Techincal";
export default function service() {
  return <Techinical />;
}
