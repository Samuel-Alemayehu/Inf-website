import Admin from "../../components/Admin/Admin"
export default function Admining() {
  return < Admin/>;
}