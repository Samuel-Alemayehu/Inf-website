import Life from "../../components/Lifecare/Life";
export default function Medial() {
  return <Life/>;
}
