import Medical from "../../components/Medical/medical";
export default function Medial() {
  return <Medical />;
}
