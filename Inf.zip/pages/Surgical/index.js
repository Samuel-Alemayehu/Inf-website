import Surgical from "../../components/Surgical/Surgical";
export default function Medial() {
  return <Surgical />;
}