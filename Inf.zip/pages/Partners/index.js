import Partners from "../../components/Partners/Partners";
export default function Medial() {
  return <Partners />;
}
